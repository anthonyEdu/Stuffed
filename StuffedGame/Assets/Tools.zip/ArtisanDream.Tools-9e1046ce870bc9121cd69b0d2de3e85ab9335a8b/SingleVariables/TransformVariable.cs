﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class TransformVariable : ScriptableObject
{
    public Transform Value;
}
