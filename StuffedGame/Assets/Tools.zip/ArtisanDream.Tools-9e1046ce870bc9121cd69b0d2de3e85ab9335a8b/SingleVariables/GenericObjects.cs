﻿using UnityEngine;
using UnityEngine.Events;

[CreateAssetMenu(fileName = "GenericObjects", menuName = "Objects/Generic Objects")]
public class GenericObjects : GenericObjectsBase<Object>
{
}