﻿using UnityEngine;

[CreateAssetMenu]
public class NameId : ScriptableObject
{
}