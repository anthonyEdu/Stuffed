﻿using UnityEngine;

public abstract class Collectible : NameId
{
    public abstract void Use();
}